﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.Audio;
using UnityStandardAssets.CrossPlatformInput;
using UnityEngine.SceneManagement;
public class PlayerController : MonoBehaviour
{
    public float speed;
    private Rigidbody rb;
    private Renderer rend;
    private int count;
    private int i;
    public Text countText;
    public Text winText;
   //public Text gameText;
   //public Text restartText;
    public GameObject player1;
    public AudioSource audioS;
    public AudioSource audioS1;
    public AudioClip sound;
    public AudioClip sound1;
    public GameObject soldier;
    public Animator anim;
    private float levelTime = 0.0f;
   // private bool gameOver;
   //private bool restart;
    //public float record;
    //public readonly string str="";
    //private bool hasPlayed = false;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rend = GetComponent<Renderer>();
        sound = GetComponent<AudioClip>();
        player1 = GameObject.FindWithTag("Player1");
        audioS = GetComponent<AudioSource>();
        audioS1 = GetComponent<AudioSource>();
        anim = GetComponent<Animator>();
        count = 0;
        SetCountText();
        winText.text = "";
        //  gameOver = false;
        // restart = false;
        // gameText.text = "";
        // restartText.text = "";
        Invoke("GoToNextLevel", levelTime);
    }

    /*void Update()
    {
        RollBall();
    }*/

   
    void FixedUpdate()             //this method will call before rendering a physics
    {
       float moveX = CrossPlatformInputManager.GetAxis("Horizontal");
        //float moveX = Input.GetAxis("Horizontal");
		//float moveZ = Input.GetAxis("Vertical");
        float moveZ = CrossPlatformInputManager.GetAxis("Vertical");
        //float moveZ = CrossPlatformInputManager.;
        Vector3 movement = new Vector3(moveX,0.0f,moveZ);
        
        //  rb.velocity = movement * speed;
        rb.AddForce(movement * speed);
       /* if (levelTime<=0)
        {
            Application.LoadLevel(0);
            
        }

        if (levelTime <= 1)
        {
            Application.LoadLevel(1);
        }*/
        if(count == 12)
        {
            Application.LoadLevel(0);
            
        }
    }
   
    
  
    void OnTriggerEnter(Collider col)
    {
         Vector3 temp = new Vector3(0.1f, 0.1f, 0.1f);
        if (col.gameObject.CompareTag("Pick Up"))
        {
            col.gameObject.SetActive(false);
                      
            count = count + 1;
          //  for (i = count; i <= count; i++)
         //   {
                rend.transform.localScale = player1.transform.localScale + temp;
                rend.material.color = Color.black;
                audioS.Play();
              //  CameraController.GameOver();
                soldier = GameObject.Instantiate(soldier as GameObject);
                soldier.transform.position = rend.transform.position;
                //rb.velocity = movement * speed;
                SetCountText();
              
          //  }
          }
       
       
    }
      /*
      void OnCollisionEnter(Collision otherObj)
        {
            if (otherObj.gameObject.tag == "Enemy")
            {
                Destroy(gameObject,1f);
            }
           // countText.text = "Game Over!";
        }*/

      void SetCountText()
    {
        countText.text = "Count: " + count.ToString();
          if(count>=12)
        {
            winText.text = "You Win!";
            audioS1.Play();
            audioS1.clip = sound1;
            audioS1.Play();


        }
    }
    
}
